# Localizacion-de-basurales
Análisis de datos abiertos - Localización de basurales

Practico integrador para el seminario de C de la facultad de informatica (UNLP info)

A raiz de un estudio sobre el impacto ambiental de los basurales de la cuenca Matanza -
Riachuelo realizado en el año 2017, surgió la necesidad de obtener información estadı́stica
sobre los datos que dicho estudio arrojó. Para facilitar su difusión y entendimiento por
personas ajenas a la materia especı́fica de medio ambiente, se ha requerido procesar
los datos para poder generar un mapa que muestre gráficamente los distintos basurales
encontrados.
A tal fin, se tiene a disposición el dataset de basurales de la cuenca Matanza - Riachuelo
de 2017 en formato CSV, el cual deberá ser utilizado por un programa que permita cargar
ese archivo y realizar una serie de operaciones sobre sus datos, para obtener finalmente
la información deseada.

Consigna completa en /TrabajoPracticoIntegrador2019.pdf
